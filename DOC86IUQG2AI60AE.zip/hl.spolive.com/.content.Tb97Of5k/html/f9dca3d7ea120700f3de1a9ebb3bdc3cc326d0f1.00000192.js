$(document).ready(function(){
	'use strict';

	let pop_index = 0; 
	$(".pop-call").on("click",function(){
		let popName = $(this).attr("data-popup");
		// if( $(".pop_on").length > 0 ){ $(".popup." + popName).css("z-index",10 + pop_index );}
		// else{ $(".popup." + popName).fadeIn().addClass("pop_on"); }
		// pop_index++;
		$(".popup." + popName).fadeIn().addClass("pop_on");
		$(".mask").fadeIn();
	});
	$(".popup__close-btn, .popup-close").on("click",function(){
		$(this).closest(".popup").fadeOut();
		$(".mask").fadeOut();
		// $(this).closest(".popup").fadeOut().removeClass("pop_on").css("z-index",10);;
		// pop_index --;
	});

	$(".v-slide-target").on("click", function () { 
		$(this).toggleClass('on').next().slideToggle();
	});

	$(window).scroll(function(){
		if($(this).scrollTop()>= 53 ){
			$(".header").addClass("fixed");
			$('.side-banner').addClass("fixed");
		} else{
			$(".header").removeClass("fixed");
			$('.side-banner').removeClass("fixed");
		}
		if ($(this).scrollTop() >= 53) {
		}
	});

	if( $(".datepicker").length ){

		$(".datepicker:not([readonly]" ).daterangepicker({
			singleDatePicker: true,
			autoApply: true,
			locale: {
				"format": "YYYY.MM.DD",
				"daysOfWeek": ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'], 
				"monthNames": ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
			}
		});
		$(".range-datepicker:not([readonly]" ).daterangepicker({
			autoApply: true,
			locale: {
				"format": "YYYY.MM.DD",
				"daysOfWeek": ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'], 
				"monthNames": ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
			}
		});
	}
	
	const swiper = new Swiper(".main-slider-wrap", {
		loop: true,	
		parallax: true,
		autoplay: true,
		grabCursor: true,
		speed: 800,
		pagination: {
			el: ".swiper-pagination",
			clickable: true,
		},
			navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		},
	});
});


